// Objects 

// Collection of properties 


let products=[

    {
        name:"Samsung M51",
        price:23000,
        color:"black",
        
    },
    {
        name:"Roadster Watch",
        price:2000,
        color:"Gray",
        
    },
    {
        name:"Dell Monitor",
        price:2600,
        color:"Blue",
        
    },
    {
        
        price:2600,
        color:"Blue",
        
    }



]





for(let i=0;i<products.length;i++){
    console.log(products[i].name);
    console.log(products[i].price);
    console.log(products[i].color);
}








// product.quanity=23;

// console.log(product);
// console.log(product.name);
// console.log(product.price);






