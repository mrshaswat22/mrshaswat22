

// document.querySelector('.first').innerText="Saurabh";

// console.log(document.querySelector('.first').innerText);




// functions 

function doSomething(){

    let name=document.querySelector("#inp").value;
    // console.log(name);

    document.querySelector("#sec").innerHTML=`<h1>${name}</h1>`;

}














