// Conditional Statements 

// if 

// if(condn)
// {

//     // code //

// }



// conditional /comparison operators
// > < >= <= == !=

// logical operator 
// && || !

// let avg=75;


// if(avg>=50 && avg<70){
//     console.log("B Grade");
// }
// else if(avg>=70 && avg<=100){
//     console.log("A Grade");
// }
// else if(avg>=40 && avg<50){
//     console.log("C Grade");
// }
// else {
//     console.log("Fail");
// }

// loops 


// while 
// do while
// for 

let a=12;

while(a<=10)
{
    console.log(a);
    a++;
    
}


// let i=12;

// do {
//     console.log(i);
//     i++;
// }
// while(i<=10);

// var is function scoped 
// let is block scoped 


// for(let i=1;i<=10;i++)
// {

//     console.log(i);

// }


// Arrays 
// collection of elements of same type 

let arr=["Thor","ironman","captain america","hulk","hawkeye","black widow"];

console.log(arr.length);

for(let i=0;i<arr.length;i++){

    console.log(arr[i],i);

}





































